'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const pathname = usePathname();

  const isActive = (path: string) => {
    return pathname.includes(path);
  };

  const navItems = [
    {
      label: 'التمارين',
      href: '/dashboard/exercises',
      key: 'exercises',
    },
    {
      label: 'الإحصائيات',
      href: '/dashboard/stats',
      key: 'stats',
    },
    {
      label: 'الانضمام إلى الحصة',
      href: '/dashboard/meeting',
      key: 'meeting',
    },
  ];

  return (
    <div className="flex h-screen bg-background">
      {/* Sidebar */}
      <aside
        className={`fixed right-0 top-0 h-full w-64 bg-sidebar border-l border-sidebar-border transform transition-transform duration-300 z-40 ${
          sidebarOpen ? 'translate-x-0' : 'translate-x-full'
        }`}
      >
        <div className="flex flex-col h-full p-6">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-2xl font-bold text-sidebar-primary">اللغة الألمانية</h2>
            <button
              onClick={() => setSidebarOpen(false)}
              className="md:hidden text-sidebar-foreground hover:text-sidebar-accent"
            >
              <X size={24} />
            </button>
          </div>

          <nav className="flex-1 space-y-2">
            {navItems.map((item) => (
              <Link key={item.key} href={item.href}>
                <button
                  onClick={() => {
                    setSidebarOpen(false);
                  }}
                  className={`w-full text-right px-4 py-3 rounded-lg transition-colors ${
                    isActive(item.key)
                      ? 'bg-sidebar-accent text-sidebar-accent-foreground font-semibold'
                      : 'text-sidebar-foreground hover:bg-sidebar-accent/10'
                  }`}
                >
                  {item.label}
                </button>
              </Link>
            ))}
          </nav>

          <div className="space-y-2 border-t border-sidebar-border pt-6">
            <Link href="/admin/exercises/add">
              <Button
                variant="outline"
                className="w-full justify-center border-sidebar-border text-sidebar-foreground hover:bg-sidebar-accent/10"
              >
                لوحة التحكم
              </Button>
            </Link>
            <button className="w-full text-sidebar-foreground hover:text-sidebar-accent text-sm transition-colors py-2">
              تسجيل الخروج
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col ml-0 md:ml-64 overflow-hidden">
        {/* Top Bar */}
        <div className="h-16 border-b border-border/40 bg-card/50 backdrop-blur-sm flex items-center px-6 sticky top-0 z-30">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="md:hidden text-foreground hover:text-accent"
          >
            <Menu size={24} />
          </button>
          <div className="ml-auto"></div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-auto">
          <div className="p-6 md:p-8">
            {children}
          </div>
        </div>
      </main>

      {/* Mobile Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/50 md:hidden z-30"
          onClick={() => setSidebarOpen(false)}
        />
      )}
    </div>
  );
}
